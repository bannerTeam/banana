<?php
return array (
    'name' => '苹果CMS',
    'copyright' => 'MacCMS.COM',
    'url' => 'http://www.maccms.com/',
    'code' => '2018.05.17.1050',
    'license' => '免费版',
);
?>