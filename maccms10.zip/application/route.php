<?php
return array (
  'map' => 
  array (
    0 => 'map/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'rss' => 
  array (
    0 => 'rss/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'gbook/index' => 
  array (
    0 => 'gbook/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'gbook/index/page/[:page]' => 
  array (
    0 => 'gbook/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'topic/index' => 
  array (
    0 => 'topic/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'topic/index/page/[:page]' => 
  array (
    0 => 'topic/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'topic/detail/id/:id' => 
  array (
    0 => 'topic/detail',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/type/id/:id' => 
  array (
    0 => 'vod/type',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/show/id/:id' => 
  array (
    0 => 'vod/show',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/detail/id/:id' => 
  array (
    0 => 'vod/detail',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/rss/id/:id' => 
  array (
    0 => 'vod/rss',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/play/id/:id/sid/:sid/nid/:nid' => 
  array (
    0 => 'vod/play',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/down/id/:id/sid/:sid/nid/:nid' => 
  array (
    0 => 'vod/down',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/wd/:wd' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/tid/:tid' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/level/:level' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/year/:year' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/area/:area' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/lang/:lang' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/letter/:letter' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/actor/:actor' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/director/:director' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/tag/:tag' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/class/:class' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/state/:state' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search/actor/:actor/area/:area/by/:by/class/:class/director/:director/lang/:lang/letter/:letter/level/:level/order/:order/state/:state/tag/:tag/wd/:wd/year/:year' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'vod/search' => 
  array (
    0 => 'vod/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/type/id/:id' => 
  array (
    0 => 'art/type',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/show/id/:id' => 
  array (
    0 => 'art/show',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/detail/id/:id' => 
  array (
    0 => 'art/detail',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/detail/id/:id/page/[:page]' => 
  array (
    0 => 'art/detail',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/rss/id/:id' => 
  array (
    0 => 'art/rss',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/rss/id/:id/page/[:page]' => 
  array (
    0 => 'art/rss',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/wd/:wd' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/tid/:tid' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/level/:level' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/letter/:letter' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/tag/:tag' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/class/:class' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search/by/:by/class/:class/level/:level/letter/:letter/order/:order/tag/:tag/wd/:wd' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'art/search' => 
  array (
    0 => 'art/search',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
  'label/:file' => 
  array (
    0 => 'label/index',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\w+',
    ),
  ),
);
?>