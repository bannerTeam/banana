# fastamin-addons
FastAdmin插件模块

## 使用方法
http://doc.fastadmin.net/docs/addons.html

## 特别感谢
https://github.com/5ini99/think-addons