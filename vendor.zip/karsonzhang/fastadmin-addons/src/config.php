<?php

return [
    'addons_on'  => true,
];
