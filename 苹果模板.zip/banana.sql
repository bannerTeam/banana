/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50709
Source Host           : localhost:3306
Source Database       : banana

Target Server Type    : MYSQL
Target Server Version : 50709
File Encoding         : 65001

Date: 2018-05-18 23:53:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for mac_actor
-- ----------------------------
DROP TABLE IF EXISTS `mac_actor`;
CREATE TABLE `mac_actor` (
  `actor_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actor_name` varchar(255) NOT NULL DEFAULT '',
  `actor_en` varchar(255) NOT NULL DEFAULT '',
  `actor_alias` varchar(255) NOT NULL DEFAULT '',
  `actor_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_letter` char(1) NOT NULL DEFAULT '',
  `actor_sex` char(1) NOT NULL DEFAULT '',
  `actor_color` varchar(6) NOT NULL DEFAULT '',
  `actor_pic` varchar(255) NOT NULL DEFAULT '',
  `actor_blurb` varchar(255) NOT NULL DEFAULT '',
  `actor_remarks` varchar(100) NOT NULL DEFAULT '',
  `actor_area` varchar(10) NOT NULL DEFAULT '',
  `actor_height` varchar(10) NOT NULL DEFAULT '',
  `actor_weight` varchar(10) NOT NULL DEFAULT '',
  `actor_birthday` varchar(10) NOT NULL DEFAULT '',
  `actor_birtharea` varchar(10) NOT NULL DEFAULT '',
  `actor_blood` varchar(10) NOT NULL DEFAULT '',
  `actor_starsign` varchar(10) NOT NULL DEFAULT '',
  `actor_school` varchar(20) NOT NULL DEFAULT '',
  `actor_works` varchar(255) NOT NULL DEFAULT '',
  `actor_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_time` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `actor_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `actor_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_tpl` varchar(30) NOT NULL DEFAULT '',
  `actor_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `actor_content` text NOT NULL,
  PRIMARY KEY (`actor_id`),
  KEY `actor_name` (`actor_name`) USING BTREE,
  KEY `actor_en` (`actor_en`) USING BTREE,
  KEY `actor_letter` (`actor_letter`) USING BTREE,
  KEY `actor_level` (`actor_level`) USING BTREE,
  KEY `actor_time` (`actor_time`) USING BTREE,
  KEY `actor_time_add` (`actor_time_add`) USING BTREE,
  KEY `actor_sex` (`actor_sex`),
  KEY `actor_area` (`actor_area`),
  KEY `actor_up` (`actor_up`),
  KEY `actor_down` (`actor_down`),
  KEY `actor_score` (`actor_score`),
  KEY `actor_score_all` (`actor_score_all`),
  KEY `actor_score_num` (`actor_score_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_actor
-- ----------------------------

-- ----------------------------
-- Table structure for mac_admin
-- ----------------------------
DROP TABLE IF EXISTS `mac_admin`;
CREATE TABLE `mac_admin` (
  `admin_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) NOT NULL DEFAULT '',
  `admin_pwd` char(32) NOT NULL DEFAULT '',
  `admin_random` char(32) NOT NULL DEFAULT '',
  `admin_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `admin_auth` text NOT NULL,
  `admin_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_num` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`),
  KEY `admin_name` (`admin_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_admin
-- ----------------------------
INSERT INTO `mac_admin` VALUES ('1', 'admin', 'e15f99c42786c0625b5998c8ddfca448', 'f4e866d6c177d88fb796b797647fbbaf', '1', '', '1526644339', '2130706433', '0', '0', '0');

-- ----------------------------
-- Table structure for mac_art
-- ----------------------------
DROP TABLE IF EXISTS `mac_art`;
CREATE TABLE `mac_art` (
  `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_name` varchar(255) NOT NULL DEFAULT '',
  `art_sub` varchar(255) NOT NULL DEFAULT '',
  `art_en` varchar(255) NOT NULL DEFAULT '',
  `art_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_letter` char(1) NOT NULL DEFAULT '',
  `art_color` varchar(6) NOT NULL DEFAULT '',
  `art_from` varchar(30) NOT NULL DEFAULT '',
  `art_author` varchar(30) NOT NULL DEFAULT '',
  `art_tag` varchar(100) NOT NULL DEFAULT '',
  `art_class` varchar(255) NOT NULL DEFAULT '',
  `art_pic` varchar(255) NOT NULL DEFAULT '',
  `art_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `art_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `art_blurb` varchar(255) NOT NULL DEFAULT '',
  `art_remarks` varchar(100) NOT NULL DEFAULT '',
  `art_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `art_tpl` varchar(30) NOT NULL DEFAULT '',
  `art_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_time` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `art_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `art_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `art_rel_art` varchar(255) NOT NULL DEFAULT '',
  `art_rel_vod` varchar(255) NOT NULL DEFAULT '',
  `art_title` mediumtext NOT NULL,
  `art_note` mediumtext NOT NULL,
  `art_content` mediumtext NOT NULL,
  PRIMARY KEY (`art_id`),
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `art_level` (`art_level`) USING BTREE,
  KEY `art_hits` (`art_hits`) USING BTREE,
  KEY `art_time` (`art_time`) USING BTREE,
  KEY `art_letter` (`art_letter`) USING BTREE,
  KEY `art_down` (`art_down`) USING BTREE,
  KEY `art_up` (`art_up`) USING BTREE,
  KEY `art_tag` (`art_tag`) USING BTREE,
  KEY `art_name` (`art_name`) USING BTREE,
  KEY `art_enname` (`art_en`) USING BTREE,
  KEY `art_hits_day` (`art_hits_day`) USING BTREE,
  KEY `art_hits_week` (`art_hits_week`) USING BTREE,
  KEY `art_hits_month` (`art_hits_month`) USING BTREE,
  KEY `art_time_add` (`art_time_add`) USING BTREE,
  KEY `art_time_make` (`art_time_make`) USING BTREE,
  KEY `art_lock` (`art_lock`),
  KEY `art_score` (`art_score`),
  KEY `art_score_all` (`art_score_all`),
  KEY `art_score_num` (`art_score_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_art
-- ----------------------------

-- ----------------------------
-- Table structure for mac_card
-- ----------------------------
DROP TABLE IF EXISTS `mac_card`;
CREATE TABLE `mac_card` (
  `card_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_no` varchar(16) NOT NULL DEFAULT '',
  `card_pwd` varchar(8) NOT NULL DEFAULT '',
  `card_money` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_use_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `card_sale_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `card_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `card_use_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`card_id`),
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `card_add_time` (`card_add_time`) USING BTREE,
  KEY `card_use_time` (`card_use_time`) USING BTREE,
  KEY `card_no` (`card_no`),
  KEY `card_pwd` (`card_pwd`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_card
-- ----------------------------

-- ----------------------------
-- Table structure for mac_cj_content
-- ----------------------------
DROP TABLE IF EXISTS `mac_cj_content`;
CREATE TABLE `mac_cj_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` char(255) NOT NULL,
  `title` char(100) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nodeid` (`nodeid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of mac_cj_content
-- ----------------------------

-- ----------------------------
-- Table structure for mac_cj_history
-- ----------------------------
DROP TABLE IF EXISTS `mac_cj_history`;
CREATE TABLE `mac_cj_history` (
  `md5` char(32) NOT NULL,
  PRIMARY KEY (`md5`),
  KEY `md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- ----------------------------
-- Records of mac_cj_history
-- ----------------------------

-- ----------------------------
-- Table structure for mac_cj_node
-- ----------------------------
DROP TABLE IF EXISTS `mac_cj_node`;
CREATE TABLE `mac_cj_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sourcecharset` varchar(8) NOT NULL,
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlpage` text NOT NULL,
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `page_base` char(255) NOT NULL,
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `url_contain` char(100) NOT NULL,
  `url_except` char(100) NOT NULL,
  `url_start` char(100) NOT NULL DEFAULT '',
  `url_end` char(100) NOT NULL DEFAULT '',
  `title_rule` char(100) NOT NULL,
  `title_html_rule` text NOT NULL,
  `type_rule` char(100) NOT NULL,
  `type_html_rule` text NOT NULL,
  `content_rule` char(100) NOT NULL,
  `content_html_rule` text NOT NULL,
  `content_page_start` char(100) NOT NULL,
  `content_page_end` char(100) NOT NULL,
  `content_page_rule` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_nextpage` char(100) NOT NULL,
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `customize_config` text NOT NULL,
  `program_config` text NOT NULL,
  `mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of mac_cj_node
-- ----------------------------

-- ----------------------------
-- Table structure for mac_collect
-- ----------------------------
DROP TABLE IF EXISTS `mac_collect`;
CREATE TABLE `mac_collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `collect_name` varchar(30) NOT NULL DEFAULT '',
  `collect_url` varchar(255) NOT NULL DEFAULT '',
  `collect_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_appid` varchar(30) NOT NULL DEFAULT '',
  `collect_appkey` varchar(30) NOT NULL DEFAULT '',
  `collect_param` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`collect_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_collect
-- ----------------------------

-- ----------------------------
-- Table structure for mac_comment
-- ----------------------------
DROP TABLE IF EXISTS `mac_comment`;
CREATE TABLE `mac_comment` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_name` varchar(60) NOT NULL DEFAULT '',
  `comment_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_content` varchar(255) NOT NULL DEFAULT '',
  `comment_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_reply` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_report` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `comment_mid` (`comment_mid`) USING BTREE,
  KEY `comment_rid` (`comment_rid`) USING BTREE,
  KEY `comment_time` (`comment_time`) USING BTREE,
  KEY `comment_pid` (`comment_pid`),
  KEY `user_id` (`user_id`),
  KEY `comment_reply` (`comment_reply`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_comment
-- ----------------------------

-- ----------------------------
-- Table structure for mac_gbook
-- ----------------------------
DROP TABLE IF EXISTS `mac_gbook`;
CREATE TABLE `mac_gbook` (
  `gbook_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbook_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `gbook_name` varchar(60) NOT NULL DEFAULT '',
  `gbook_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_content` varchar(255) NOT NULL DEFAULT '',
  `gbook_reply` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`gbook_id`),
  KEY `gbook_rid` (`gbook_rid`) USING BTREE,
  KEY `gbook_time` (`gbook_time`) USING BTREE,
  KEY `gbook_reply_time` (`gbook_reply_time`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `gbook_reply` (`gbook_reply`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_gbook
-- ----------------------------

-- ----------------------------
-- Table structure for mac_group
-- ----------------------------
DROP TABLE IF EXISTS `mac_group`;
CREATE TABLE `mac_group` (
  `group_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `group_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `group_type` varchar(255) NOT NULL DEFAULT '',
  `group_popedom` text NOT NULL,
  `group_points_day` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_week` smallint(6) NOT NULL DEFAULT '0',
  `group_points_month` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_year` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_free` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `group_status` (`group_status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_group
-- ----------------------------
INSERT INTO `mac_group` VALUES ('1', '游客', '1', ',1,6,7,8,9,10,11,12,2,13,14,15,16,3,4,5,17,18,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\"},\"17\":{\"1\":\"1\",\"2\":\"2\"},\"18\":{\"1\":\"1\",\"2\":\"2\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('2', '默认会员', '1', ',1,6,7,8,9,10,11,12,2,13,14,15,16,3,4,5,17,18,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\"},\"17\":{\"1\":\"1\",\"2\":\"2\"},\"18\":{\"1\":\"1\",\"2\":\"2\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('3', 'VIP会员', '1', ',1,6,7,8,9,10,11,12,2,13,14,15,16,3,4,5,17,18,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"4\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\"},\"17\":{\"1\":\"1\",\"2\":\"2\"},\"18\":{\"1\":\"1\",\"2\":\"2\"}}', '10', '70', '300', '3600', '0');

-- ----------------------------
-- Table structure for mac_link
-- ----------------------------
DROP TABLE IF EXISTS `mac_link`;
CREATE TABLE `mac_link` (
  `link_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `link_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `link_name` varchar(60) NOT NULL DEFAULT '',
  `link_sort` smallint(6) NOT NULL DEFAULT '0',
  `link_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_logo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_sort` (`link_sort`) USING BTREE,
  KEY `link_type` (`link_type`) USING BTREE,
  KEY `link_add_time` (`link_add_time`),
  KEY `link_time` (`link_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_link
-- ----------------------------

-- ----------------------------
-- Table structure for mac_msg
-- ----------------------------
DROP TABLE IF EXISTS `mac_msg`;
CREATE TABLE `mac_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_to` varchar(30) NOT NULL DEFAULT '',
  `msg_code` varchar(10) NOT NULL DEFAULT '',
  `msg_content` varchar(255) NOT NULL DEFAULT '',
  `msg_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  KEY `msg_code` (`msg_code`),
  KEY `msg_time` (`msg_time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_msg
-- ----------------------------

-- ----------------------------
-- Table structure for mac_order
-- ----------------------------
DROP TABLE IF EXISTS `mac_order`;
CREATE TABLE `mac_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `order_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `order_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_points` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_pay_type` varchar(10) NOT NULL DEFAULT '',
  `order_pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_id`),
  KEY `order_code` (`order_code`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `order_time` (`order_time`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_order
-- ----------------------------

-- ----------------------------
-- Table structure for mac_role
-- ----------------------------
DROP TABLE IF EXISTS `mac_role`;
CREATE TABLE `mac_role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `role_name` varchar(255) NOT NULL DEFAULT '',
  `role_en` varchar(255) NOT NULL DEFAULT '',
  `role_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_letter` char(1) NOT NULL DEFAULT '',
  `role_color` varchar(6) NOT NULL DEFAULT '',
  `role_actor` varchar(255) NOT NULL DEFAULT '',
  `role_remarks` varchar(100) NOT NULL DEFAULT '',
  `role_pic` varchar(255) NOT NULL DEFAULT '',
  `role_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `role_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_time` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `role_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `role_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `role_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_tpl` varchar(30) NOT NULL DEFAULT '',
  `role_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `role_content` text NOT NULL,
  PRIMARY KEY (`role_id`),
  KEY `role_rid` (`role_rid`),
  KEY `role_name` (`role_name`),
  KEY `role_en` (`role_en`),
  KEY `role_letter` (`role_letter`),
  KEY `role_actor` (`role_actor`),
  KEY `role_level` (`role_level`),
  KEY `role_time` (`role_time`),
  KEY `role_time_add` (`role_time_add`),
  KEY `role_score` (`role_score`),
  KEY `role_score_all` (`role_score_all`),
  KEY `role_score_num` (`role_score_num`),
  KEY `role_up` (`role_up`),
  KEY `role_down` (`role_down`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_role
-- ----------------------------

-- ----------------------------
-- Table structure for mac_tmpvod
-- ----------------------------
DROP TABLE IF EXISTS `mac_tmpvod`;
CREATE TABLE `mac_tmpvod` (
  `name1` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_tmpvod
-- ----------------------------

-- ----------------------------
-- Table structure for mac_topic
-- ----------------------------
DROP TABLE IF EXISTS `mac_topic`;
CREATE TABLE `mac_topic` (
  `topic_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `topic_name` varchar(255) NOT NULL DEFAULT '',
  `topic_en` varchar(255) NOT NULL DEFAULT '',
  `topic_sub` varchar(255) NOT NULL DEFAULT '',
  `topic_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `topic_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `topic_letter` char(1) NOT NULL DEFAULT '',
  `topic_color` varchar(6) NOT NULL DEFAULT '',
  `topic_tpl` varchar(30) NOT NULL DEFAULT '',
  `topic_type` varchar(255) NOT NULL DEFAULT '',
  `topic_pic` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `topic_key` varchar(255) NOT NULL DEFAULT '',
  `topic_des` varchar(255) NOT NULL DEFAULT '',
  `topic_title` varchar(255) NOT NULL DEFAULT '',
  `topic_blurb` varchar(255) NOT NULL DEFAULT '',
  `topic_remarks` varchar(100) NOT NULL DEFAULT '',
  `topic_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `topic_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `topic_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score_num` smallint(6) unsigned NOT NULL DEFAULT '0',
  `topic_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_time` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_tag` varchar(255) NOT NULL DEFAULT '',
  `topic_rel_vod` text,
  `topic_rel_art` text,
  `topic_content` text,
  `topic_extend` text,
  PRIMARY KEY (`topic_id`),
  KEY `topic_sort` (`topic_sort`) USING BTREE,
  KEY `topic_level` (`topic_level`) USING BTREE,
  KEY `topic_score` (`topic_score`) USING BTREE,
  KEY `topic_score_all` (`topic_score_all`) USING BTREE,
  KEY `topic_score_num` (`topic_score_num`) USING BTREE,
  KEY `topic_hits` (`topic_hits`) USING BTREE,
  KEY `topic_hits_day` (`topic_hits_day`) USING BTREE,
  KEY `topic_hits_week` (`topic_hits_week`) USING BTREE,
  KEY `topic_hits_month` (`topic_hits_month`) USING BTREE,
  KEY `topic_time_add` (`topic_time_add`) USING BTREE,
  KEY `topic_time` (`topic_time`) USING BTREE,
  KEY `topic_time_hits` (`topic_time_hits`) USING BTREE,
  KEY `topic_name` (`topic_name`),
  KEY `topic_en` (`topic_en`),
  KEY `topic_up` (`topic_up`),
  KEY `topic_down` (`topic_down`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_topic
-- ----------------------------

-- ----------------------------
-- Table structure for mac_type
-- ----------------------------
DROP TABLE IF EXISTS `mac_type`;
CREATE TABLE `mac_type` (
  `type_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL DEFAULT '',
  `type_en` varchar(60) NOT NULL DEFAULT '',
  `type_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_mid` smallint(6) unsigned NOT NULL DEFAULT '1',
  `type_pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `type_tpl` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_list` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_detail` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `type_key` varchar(255) NOT NULL DEFAULT '',
  `type_des` varchar(255) NOT NULL DEFAULT '',
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_union` varchar(255) NOT NULL DEFAULT '',
  `type_extend` text,
  PRIMARY KEY (`type_id`),
  KEY `type_sort` (`type_sort`) USING BTREE,
  KEY `type_pid` (`type_pid`) USING BTREE,
  KEY `type_name` (`type_name`),
  KEY `type_en` (`type_en`),
  KEY `type_mid` (`type_mid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_type
-- ----------------------------
INSERT INTO `mac_type` VALUES ('1', '电影', 'dianying', '1', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电影,电影大全,电影天堂,最新电影,好看的电影,电影排行榜', '为您提供更新电影、好看的电影排行榜及电影迅雷下载，免费在线观看伦理电影、动作片、喜剧片、爱情片、搞笑片等全新电影。', '电影', '', '{\"class\":\"\\u559c\\u5267,\\u7231\\u60c5,\\u6050\\u6016,\\u52a8\\u4f5c,\\u79d1\\u5e7b,\\u5267\\u60c5,\\u6218\\u4e89,\\u8b66\\u532a,\\u72af\\u7f6a,\\u52a8\\u753b,\\u5947\\u5e7b,\\u6b66\\u4fa0,\\u5192\\u9669,\\u67aa\\u6218,\\u6050\\u6016,\\u60ac\\u7591,\\u60ca\\u609a,\\u7ecf\\u5178,\\u9752\\u6625,\\u6587\\u827a,\\u5fae\\u7535\\u5f71,\\u53e4\\u88c5,\\u5386\\u53f2,\\u8fd0\\u52a8,\\u519c\\u6751,\\u513f\\u7ae5,\\u7f51\\u7edc\\u7535\\u5f71\",\"area\":\"\\u5927\\u9646,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u7f8e\\u56fd,\\u6cd5\\u56fd,\\u82f1\\u56fd,\\u65e5\\u672c,\\u97e9\\u56fd,\\u5fb7\\u56fd,\\u6cf0\\u56fd,\\u5370\\u5ea6,\\u610f\\u5927\\u5229,\\u897f\\u73ed\\u7259,\\u52a0\\u62ff\\u5927,\\u5176\\u4ed6\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u6cd5\\u8bed,\\u5fb7\\u8bed,\\u5176\\u5b83\",\"year\":\"2018,2017,2016,2015,2014,2013,2012,2011,2010\",\"star\":\"\\u738b\\u5b9d\\u5f3a,\\u9ec4\\u6e24,\\u5468\\u8fc5,\\u5468\\u51ac\\u96e8,\\u8303\\u51b0\\u51b0,\\u9648\\u5b66\\u51ac,\\u9648\\u4f1f\\u9706,\\u90ed\\u91c7\\u6d01,\\u9093\\u8d85,\\u6210\\u9f99,\\u845b\\u4f18,\\u6797\\u6b63\\u82f1,\\u5f20\\u5bb6\\u8f89,\\u6881\\u671d\\u4f1f,\\u5f90\\u5ce5,\\u90d1\\u607a,\\u5434\\u5f66\\u7956,\\u5218\\u5fb7\\u534e,\\u5468\\u661f\\u9a70,\\u6797\\u9752\\u971e,\\u5468\\u6da6\\u53d1,\\u674e\\u8fde\\u6770,\\u7504\\u5b50\\u4e39,\\u53e4\\u5929\\u4e50,\\u6d2a\\u91d1\\u5b9d,\\u59da\\u6668,\\u502a\\u59ae,\\u9ec4\\u6653\\u660e,\\u5f6d\\u4e8e\\u664f,\\u6c64\\u552f,\\u9648\\u5c0f\\u6625\",\"director\":\"\\u51af\\u5c0f\\u521a,\\u5f20\\u827a\\u8c0b,\\u5434\\u5b87\\u68ee,\\u9648\\u51ef\\u6b4c,\\u5f90\\u514b,\\u738b\\u5bb6\\u536b,\\u59dc\\u6587,\\u5468\\u661f\\u9a70,\\u674e\\u5b89\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}');
INSERT INTO `mac_type` VALUES ('2', '连续剧', 'lianxuju', '2', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '电视剧,最新电视剧,好看的电视剧,热播电视剧,电视剧在线观看', '为您提供2018新电视剧排行榜，韩国电视剧、泰国电视剧、香港TVB全新电视剧排行榜、好看的电视剧等热播电视剧排行榜，并提供免费高清电视剧下载及在线观看。', '电视剧', '', '{\"class\":\"\\u53e4\\u88c5,\\u6218\\u4e89,\\u9752\\u6625\\u5076\\u50cf,\\u559c\\u5267,\\u5bb6\\u5ead,\\u72af\\u7f6a,\\u52a8\\u4f5c,\\u5947\\u5e7b,\\u5267\\u60c5,\\u5386\\u53f2,\\u7ecf\\u5178,\\u4e61\\u6751,\\u60c5\\u666f,\\u5546\\u6218,\\u7f51\\u5267,\\u5176\\u4ed6\",\"area\":\"\\u5185\\u5730,\\u97e9\\u56fd,\\u9999\\u6e2f,\\u53f0\\u6e7e,\\u65e5\\u672c,\\u7f8e\\u56fd,\\u6cf0\\u56fd,\\u82f1\\u56fd,\\u65b0\\u52a0\\u5761,\\u5176\\u4ed6\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2006,2005,2004\",\"star\":\"\\u738b\\u5b9d\\u5f3a,\\u80e1\\u6b4c,\\u970d\\u5efa\\u534e,\\u8d75\\u4e3d\\u9896,\\u5218\\u6d9b,\\u5218\\u8bd7\\u8bd7,\\u9648\\u4f1f\\u9706,\\u5434\\u5947\\u9686,\\u9646\\u6bc5,\\u5510\\u5ae3,\\u5173\\u6653\\u5f64,\\u5b59\\u4fea,\\u674e\\u6613\\u5cf0,\\u5f20\\u7ff0,\\u674e\\u6668,\\u8303\\u51b0\\u51b0,\\u6797\\u5fc3\\u5982,\\u6587\\u7ae0,\\u9a6c\\u4f0a\\u740d,\\u4f5f\\u5927\\u4e3a,\\u5b59\\u7ea2\\u96f7,\\u9648\\u5efa\\u658c,\\u674e\\u5c0f\\u7490\",\"director\":\"\\u5f20\\u7eaa\\u4e2d,\\u674e\\u5c11\\u7ea2,\\u5218\\u6c5f,\\u5b54\\u7b19,\\u5f20\\u9ece,\\u5eb7\\u6d2a\\u96f7,\\u9ad8\\u5e0c\\u5e0c,\\u80e1\\u73ab,\\u8d75\\u5b9d\\u521a,\\u90d1\\u6653\\u9f99\",\"state\":\"\\u6b63\\u7247,\\u9884\\u544a\\u7247,\\u82b1\\u7d6e\",\"version\":\"\\u9ad8\\u6e05\\u7248,\\u5267\\u573a\\u7248,\\u62a2\\u5148\\u7248,OVA,TV,\\u5f71\\u9662\\u7248\"}');
INSERT INTO `mac_type` VALUES ('3', '综艺', 'zongyi', '3', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '综艺,综艺节目,最新综艺节目,综艺节目排行榜', '为您提供新综艺节目、好看的综艺节目排行榜，免费高清在线观看选秀、情感、访谈、搞笑、真人秀、脱口秀等热门综艺节目。', '综艺', '', '{\"class\":\"\\u9009\\u79c0,\\u60c5\\u611f,\\u8bbf\\u8c08,\\u64ad\\u62a5,\\u65c5\\u6e38,\\u97f3\\u4e50,\\u7f8e\\u98df,\\u7eaa\\u5b9e,\\u66f2\\u827a,\\u751f\\u6d3b,\\u6e38\\u620f\\u4e92\\u52a8,\\u8d22\\u7ecf,\\u6c42\\u804c\",\"area\":\"\\u5185\\u5730,\\u6e2f\\u53f0,\\u65e5\\u97e9,\\u6b27\\u7f8e\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004\",\"star\":\"\\u4f55\\u7085,\\u6c6a\\u6db5,\\u8c22\\u5a1c,\\u5468\\u7acb\\u6ce2,\\u9648\\u9c81\\u8c6b,\\u5b5f\\u975e,\\u674e\\u9759,\\u6731\\u519b,\\u6731\\u4e39,\\u534e\\u5c11,\\u90ed\\u5fb7\\u7eb2,\\u6768\\u6f9c\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('4', '动漫', 'dongman', '4', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '动漫,动漫大全,最新动漫,好看的动漫,日本动漫,动漫排行榜', '为您提供新动漫、好看的动漫排行榜，免费高清在线观看热血动漫、卡通动漫、新番动漫、百合动漫、搞笑动漫、国产动漫、动漫电影等热门动漫。', '动画片', '', '{\"class\":\"\\u60c5\\u611f,\\u79d1\\u5e7b,\\u70ed\\u8840,\\u63a8\\u7406,\\u641e\\u7b11,\\u5192\\u9669,\\u841d\\u8389,\\u6821\\u56ed,\\u52a8\\u4f5c,\\u673a\\u6218,\\u8fd0\\u52a8,\\u6218\\u4e89,\\u5c11\\u5e74,\\u5c11\\u5973,\\u793e\\u4f1a,\\u539f\\u521b,\\u4eb2\\u5b50,\\u76ca\\u667a,\\u52b1\\u5fd7,\\u5176\\u4ed6\",\"area\":\"\\u56fd\\u4ea7,\\u65e5\\u672c,\\u6b27\\u7f8e,\\u5176\\u4ed6\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"TV\\u7248,\\u7535\\u5f71\\u7248,OVA\\u7248,\\u771f\\u4eba\\u7248\"}');
INSERT INTO `mac_type` VALUES ('5', '资讯', 'zixun', '5', '2', '0', '1', 'type.html', 'show.html', 'detail.html', '', '', '最新影视资讯,电影资讯,娱乐资讯', '本站提供最新电影,电视剧,综艺,动漫的资讯信息,一览无遗', '最新资讯-推荐资讯', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('7', '喜剧片', 'xijupian', '2', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的喜剧片,最新喜剧片,经典喜剧片,国语喜剧片电影', '2018最新喜剧片，好看的喜剧片大全和排行榜推荐，免费喜剧片在线观看和视频在线播放是由本网站整理和收录，欢迎喜剧片爱好者来到这里在线观看喜剧片', '好看的喜剧片-最新喜剧片-经典喜剧片-最新喜剧片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('6', '动作片', 'dongzuopian', '1', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的动作片,最新动作片,经典动作片,国语动作片电影', '2018最新动作片，好看的动作片大全和排行榜推荐，免费动作片在线观看和视频在线播放是由本网站整理和收录，欢迎动作片爱好者来到这里在线观看动作片', '好看的动作片-最新动作片-经典动作片-最新动作片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('8', '爱情片', 'aiqingpian', '3', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的爱情片,最新爱情片,经典爱情片,国语爱情片电影', '2018最新爱情片，好看的爱情片大全和排行榜推荐，免费爱情片在线观看和视频在线播放是由本网站整理和收录，欢迎爱情片爱好者来到这里在线观看爱情片', '好看的爱情片-最新爱情片-经典爱情片-最新爱情片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('9', '科幻片', 'kehuanpian', '4', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的科幻片,最新科幻片,经典科幻片,国语科幻片电影', '2018最新科幻片，好看的科幻片大全和排行榜推荐，免费科幻片在线观看和视频在线播放是由本网站整理和收录，欢迎科幻片爱好者来到这里在线观看科幻片', '好看的科幻片-最新科幻片-经典科幻片-最新科幻片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('10', '恐怖片', 'kongbupian', '5', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的恐怖片,最新恐怖片,经典恐怖片,国语恐怖片电影', '2018最新恐怖片，好看的恐怖片大全和排行榜推荐，免费恐怖片在线观看和视频在线播放是由本网站整理和收录，欢迎恐怖片爱好者来到这里在线观看恐怖片', '好看的恐怖片-最新恐怖片-经典恐怖片-最新恐怖片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('11', '剧情片', 'juqingpian', '6', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的剧情片,最新剧情片,经典剧情片,国语剧情片电影', '2018最新剧情片，好看的剧情片大全和排行榜推荐，免费剧情片在线观看和视频在线播放是由本网站整理和收录，欢迎剧情片爱好者来到这里在线观看剧情片', '好看的剧情片-最新剧情片-经典剧情片-最新剧情片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('12', '战争片', 'zhanzhengpian', '7', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的战争片,最新战争片,经典战争片,国语战争片电影', '2018最新战争片，好看的战争片大全和排行榜推荐，免费战争片在线观看和视频在线播放是由本网站整理和收录，欢迎战争片爱好者来到这里在线观看战争片', '好看的战争片-最新战争片-经典战争片-最新战争片推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('13', '国产剧', 'guochanju', '1', '1', '2', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的国产剧,最新国产剧,经典国产剧,国语国产剧电影', '2018最新国产剧，好看的国产剧大全和排行榜推荐，免费国产剧在线观看和视频在线播放是由本网站整理和收录，欢迎国产剧爱好者来到这里在线观看国产剧', '好看的国产剧-最新国产剧-经典国产剧-最新国产剧推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('14', '港台剧', 'gangtaiju', '2', '1', '2', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的港台剧,最新港台剧,经典港台剧,国语港台剧电影', '2018最新港台剧，好看的港台剧大全和排行榜推荐，免费港台剧在线观看和视频在线播放是由本网站整理和收录，欢迎港台剧爱好者来到这里在线观看港台剧', '好看的港台剧-最新港台剧-经典港台剧-最新港台剧推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('15', '日韩剧', 'rihanju', '3', '1', '2', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的日韩剧,最新日韩剧,经典日韩剧,国语日韩剧电影', '2018最新日韩剧，好看的日韩剧大全和排行榜推荐，免费日韩剧在线观看和视频在线播放是由本网站整理和收录，欢迎日韩剧爱好者来到这里在线观看日韩剧', '好看的日韩剧-最新日韩剧-经典日韩剧-最新日韩剧推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('16', '欧美剧', 'oumeiju', '4', '1', '2', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '好看的欧美剧,最新欧美剧,经典欧美剧,国语欧美剧电影', '2018最新欧美剧，好看的欧美剧大全和排行榜推荐，免费欧美剧在线观看和视频在线播放是由本网站整理和收录，欢迎欧美剧爱好者来到这里在线观看欧美剧', '好看的欧美剧-最新欧美剧-经典欧美剧-最新欧美剧推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('17', '公告', 'gonggao', '1', '2', '5', '1', 'type.html', 'show.html', 'detail.html', '', '', '最新公告-最新公告推荐', '2018最新公告，公布本站最新发展动态', '最新公告-最新公告推荐', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}');
INSERT INTO `mac_type` VALUES ('18', '头条', 'toutiao', '2', '2', '5', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for mac_ulog
-- ----------------------------
DROP TABLE IF EXISTS `mac_ulog`;
CREATE TABLE `mac_ulog` (
  `ulog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_mid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ulog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ulog_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_sid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ulog_nid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ulog_id`),
  KEY `user_id` (`user_id`),
  KEY `ulog_mid` (`ulog_mid`),
  KEY `ulog_type` (`ulog_type`),
  KEY `ulog_rid` (`ulog_rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_ulog
-- ----------------------------

-- ----------------------------
-- Table structure for mac_user
-- ----------------------------
DROP TABLE IF EXISTS `mac_user`;
CREATE TABLE `mac_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_pwd` varchar(32) NOT NULL DEFAULT '',
  `user_nick_name` varchar(30) NOT NULL DEFAULT '',
  `user_qq` varchar(16) NOT NULL DEFAULT '',
  `user_email` varchar(30) NOT NULL DEFAULT '',
  `user_phone` varchar(16) NOT NULL DEFAULT '',
  `user_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_portrait` varchar(100) NOT NULL DEFAULT '',
  `user_portrait_thumb` varchar(100) NOT NULL DEFAULT '',
  `user_openid_qq` varchar(30) NOT NULL DEFAULT '',
  `user_openid_weixin` varchar(30) NOT NULL DEFAULT '',
  `user_question` varchar(255) NOT NULL DEFAULT '',
  `user_answer` varchar(255) NOT NULL DEFAULT '',
  `user_points` int(10) unsigned NOT NULL DEFAULT '0',
  `user_reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_ip` int(10) NOT NULL DEFAULT '0',
  `user_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_num` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_extend` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_random` varchar(32) NOT NULL DEFAULT '',
  `user_end_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  KEY `type_id` (`group_id`) USING BTREE,
  KEY `user_name` (`user_name`),
  KEY `user_reg_time` (`user_reg_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_user
-- ----------------------------

-- ----------------------------
-- Table structure for mac_visit
-- ----------------------------
DROP TABLE IF EXISTS `mac_visit`;
CREATE TABLE `mac_visit` (
  `visit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `visit_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `visit_ly` varchar(100) NOT NULL DEFAULT '',
  `visit_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`visit_id`),
  KEY `user_id` (`user_id`),
  KEY `visit_time` (`visit_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_visit
-- ----------------------------

-- ----------------------------
-- Table structure for mac_vod
-- ----------------------------
DROP TABLE IF EXISTS `mac_vod`;
CREATE TABLE `mac_vod` (
  `vod_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_name` varchar(255) NOT NULL DEFAULT '',
  `vod_sub` varchar(255) NOT NULL DEFAULT '',
  `vod_en` varchar(255) NOT NULL DEFAULT '',
  `vod_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_letter` char(1) NOT NULL DEFAULT '',
  `vod_color` varchar(6) NOT NULL DEFAULT '',
  `vod_tag` varchar(100) NOT NULL DEFAULT '',
  `vod_class` varchar(255) NOT NULL DEFAULT '',
  `vod_pic` varchar(255) NOT NULL DEFAULT '',
  `vod_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `vod_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `vod_actor` varchar(255) NOT NULL DEFAULT '',
  `vod_director` varchar(255) NOT NULL DEFAULT '',
  `vod_writer` varchar(100) NOT NULL DEFAULT '',
  `vod_blurb` varchar(255) NOT NULL DEFAULT '',
  `vod_remarks` varchar(100) NOT NULL DEFAULT '',
  `vod_pubdate` varchar(100) NOT NULL DEFAULT '',
  `vod_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_serial` varchar(20) NOT NULL DEFAULT '0',
  `vod_tv` varchar(30) NOT NULL DEFAULT '',
  `vod_weekday` varchar(30) NOT NULL DEFAULT '',
  `vod_area` varchar(10) NOT NULL DEFAULT '',
  `vod_lang` varchar(10) NOT NULL DEFAULT '',
  `vod_year` varchar(10) NOT NULL DEFAULT '',
  `vod_version` varchar(30) NOT NULL DEFAULT '',
  `vod_state` varchar(30) NOT NULL DEFAULT '',
  `vod_author` varchar(60) NOT NULL DEFAULT '',
  `vod_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `vod_tpl` varchar(30) NOT NULL DEFAULT '',
  `vod_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `vod_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `vod_isend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_points_play` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_points_down` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_duration` varchar(10) NOT NULL DEFAULT '',
  `vod_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `vod_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_score_num` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `vod_time` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_trysee` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_douban_id` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_douban_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `vod_reurl` varchar(255) NOT NULL DEFAULT '',
  `vod_rel_vod` varchar(255) NOT NULL DEFAULT '',
  `vod_rel_art` varchar(255) NOT NULL DEFAULT '',
  `vod_content` text NOT NULL,
  `vod_play_from` varchar(255) NOT NULL DEFAULT '',
  `vod_play_server` varchar(255) NOT NULL DEFAULT '',
  `vod_play_note` varchar(255) NOT NULL DEFAULT '',
  `vod_play_url` mediumtext NOT NULL,
  `vod_down_from` varchar(255) NOT NULL DEFAULT '',
  `vod_down_server` varchar(255) NOT NULL DEFAULT '',
  `vod_down_note` varchar(255) NOT NULL DEFAULT '',
  `vod_down_url` mediumtext NOT NULL,
  PRIMARY KEY (`vod_id`),
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `vod_level` (`vod_level`) USING BTREE,
  KEY `vod_hits` (`vod_hits`) USING BTREE,
  KEY `vod_letter` (`vod_letter`) USING BTREE,
  KEY `vod_name` (`vod_name`) USING BTREE,
  KEY `vod_year` (`vod_year`) USING BTREE,
  KEY `vod_area` (`vod_area`) USING BTREE,
  KEY `vod_lang` (`vod_lang`) USING BTREE,
  KEY `vod_tag` (`vod_tag`) USING BTREE,
  KEY `vod_class` (`vod_class`) USING BTREE,
  KEY `vod_lock` (`vod_lock`) USING BTREE,
  KEY `vod_up` (`vod_up`) USING BTREE,
  KEY `vod_down` (`vod_down`) USING BTREE,
  KEY `vod_en` (`vod_en`) USING BTREE,
  KEY `vod_hits_day` (`vod_hits_day`) USING BTREE,
  KEY `vod_hits_week` (`vod_hits_week`) USING BTREE,
  KEY `vod_hits_month` (`vod_hits_month`) USING BTREE,
  KEY `vod_points_play` (`vod_points_play`) USING BTREE,
  KEY `vod_points_down` (`vod_points_down`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE,
  KEY `vod_time_add` (`vod_time_add`) USING BTREE,
  KEY `vod_time` (`vod_time`) USING BTREE,
  KEY `vod_time_make` (`vod_time_make`) USING BTREE,
  KEY `vod_actor` (`vod_actor`) USING BTREE,
  KEY `vod_director` (`vod_director`) USING BTREE,
  KEY `vod_score_all` (`vod_score_all`) USING BTREE,
  KEY `vod_score_num` (`vod_score_num`) USING BTREE,
  KEY `vod_total` (`vod_total`) USING BTREE,
  KEY `vod_score` (`vod_score`) USING BTREE,
  KEY `vod_version` (`vod_version`),
  KEY `vod_state` (`vod_state`),
  KEY `vod_isend` (`vod_isend`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mac_vod
-- ----------------------------
INSERT INTO `mac_vod` VALUES ('1', '6', '1', '0', '一本道 041916_282 共有少女 月野美羽 ', '', 'yibendao041916_282gongyoushaonvyueyemeiyu', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0769_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '574', '777', '374', '131', '', '92', '742', '10.0', '8950', '895', '1526645541', '1526645541', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0769_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('2', '6', '1', '0', '天然素人 022716_01 爆睡中素人 冈田优子 ', '', 'tianransuren022716_01baoshuizhongsurengangtianyouzi', '1', 'T', '', '022716,素人,天然素人', '无码中文av', 'http://img.feimanzb.com/2018-5/0759_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '420', '57', '522', '410', '', '27', '815', '5.0', '2380', '476', '1526645541', '1526645541', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0759_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('3', '6', '1', '0', '一本道 111915_192 超正妹猛鬼高潮 大岛柚奈 ', '', 'yibendao111915_192chaozhengmeimengguigaochaodadaoyounai', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0770_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '882', '610', '475', '399', '', '455', '536', '1.0', '738', '738', '1526645542', '1526645542', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0770_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('4', '6', '1', '0', '一本道 022016_249 超正妹猛鬼高潮 叶山友香 ', '', 'yibendao022016_249chaozhengmeimengguigaochaoyeshanyouxiang', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0760_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '712', '187', '983', '849', '', '124', '656', '6.0', '2574', '429', '1526645543', '1526645543', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0760_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('5', '6', '1', '0', '一本道 120515_202 上班女郎 ?肉慾淫旅馆员? 北岛玲 ', '', 'yibendao120515_202shangbannvlang_rouyuyinlvguanyuan_beidaoling', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0771_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '659', '537', '795', '509', '', '786', '924', '6.0', '1800', '300', '1526645544', '1526645544', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0771_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('6', '6', '1', '0', '一本道 031616_263 和熟辣妹淫乱3P姦 白雪小鸟 ', '', 'yibendao031616_263heshulameiyinluan3Pjianbaixuexiaoniao', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0761_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '473', '411', '662', '131', '', '190', '91', '10.0', '1000', '100', '1526645544', '1526645544', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0761_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('7', '6', '1', '0', '加勒比 012916-085 如果我女友是叶山瞳 ', '', 'jialebi012916_085ruguowonvyoushiyeshantong', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0772_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '905', '558', '334', '464', '', '86', '906', '5.0', '2905', '581', '1526645545', '1526645545', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0772_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('8', '6', '1', '0', '一本道 091515_153 顶级正妹 猛鬼高潮 长谷川夏树 ', '', 'yibendao091515_153dingjizhengmeimengguigaochaochangguchuanxiashu', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0762_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '703', '729', '560', '258', '', '225', '120', '8.0', '3928', '491', '1526645546', '1526645546', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0762_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('9', '6', '1', '0', '加勒比 032116-122 真实淫乱故事 31 宫崎爱莉 ', '', 'jialebi032116_122zhenshiyinluangushi31gongqiaili', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0773_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '619', '673', '91', '262', '', '355', '482', '7.0', '4060', '580', '1526645546', '1526645546', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0773_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('10', '6', '1', '0', '一本道 091914_886 无名无毛超淫蕩的！ 宫泽美保 ', '', 'yibendao091914_886wumingwumaochaoyindangde_gongzemeibao', '1', 'Y', '', '一本道,091914', '无码中文av', 'http://img.feimanzb.com/2018-5/0763_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '402', '141', '677', '228', '', '228', '743', '9.0', '5391', '599', '1526645547', '1526645547', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0763_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('11', '6', '1', '0', '加勒比 082615-957 美微乳 夜空真寻 ', '', 'jialebi082615_957meiweiruyekongzhenxun', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0774_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '802', '882', '67', '904', '', '593', '651', '2.0', '596', '298', '1526645548', '1526645548', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0774_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('12', '6', '1', '0', 'HEYZO 0890 开发她秘密屁眼 羽月美丽爱 ', '', 'HEYZO0890kaifatamimipiyanyuyuemeiliai', '1', 'H', '', '0890,秘密屁眼,HEYZO', '无码中文av', 'http://img.feimanzb.com/2018-5/0755_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '570', '646', '12', '42', '', '200', '959', '4.0', '1708', '427', '1526645549', '1526645549', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0755_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('13', '6', '1', '0', '加勒比 072815-931 狱畜15 ～美女耻肉块～ 安城安娜 ', '', 'jialebi072815_931yuxu15_meinvchiroukuai_anchenganna', '1', 'J', '', '072815,加勒比', '无码中文av', 'http://img.feimanzb.com/2018-5/0765_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '454', '184', '262', '390', '', '800', '415', '1.0', '735', '735', '1526645549', '1526645549', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0765_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('14', '6', '1', '0', 'muramura 031516_365 OL风俗嬢彼氏も公认！藤优子 ', '', 'muramura031516_365OLfengsuniangbishi_gongren_tengyouzi', '1', 'M', '', 'muramura', '无码中文av', 'http://img.feimanzb.com/2018-5/0756_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '206', '245', '566', '700', '', '141', '769', '2.0', '1946', '973', '1526645550', '1526645550', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0756_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('15', '6', '1', '0', 'HEYZO 1112 持续生中出～肏翻柔软妹内射灌精！～ - 内村莉奈 ', '', 'HEYZO1112chixushengzhongchu_caofanrouruanmeineisheguanjing___neicunlinai', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0775_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '575', '580', '676', '720', '', '975', '772', '3.0', '2673', '891', '1526645551', '1526645551', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0775_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('16', '6', '1', '0', '加勒比 021916-100 看到马上插！～秒插吓吓你！～ 美穗乃 ', '', 'jialebi021916_100kandaomashangcha__miaochaxiaxiani__meisuinai', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0766_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '311', '938', '339', '201', '', '51', '173', '3.0', '717', '239', '1526645551', '1526645551', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0766_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('17', '6', '1', '0', '天然素人 031216_01 骗素人模肏下去偷拍流出 藤田由美子 ', '', 'tianransuren031216_01piansurenmocaoxiaqutoupailiuchutengtianyoumeizi', '1', 'T', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0757_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '164', '70', '308', '893', '', '119', '722', '9.0', '6894', '766', '1526645552', '1526645552', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0757_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('18', '6', '1', '0', 'HEYZO 1033 被黑心企业当成性玩具的OL - 本山茉莉 ', '', 'HEYZO1033beiheixinqiyedangchengxingwanjudeOL_benshanmoli', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0776_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '885', '725', '331', '546', '', '929', '170', '8.0', '1784', '223', '1526645556', '1526645556', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0776_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('19', '6', '1', '0', '加勒比 031816-119 正点★牛仔裤女郎 25 原千岁 ', '', 'jialebi031816_119zhengdian_niuzikunvlang25yuanqiansui', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0767_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '222', '653', '159', '910', '', '232', '267', '8.0', '2872', '359', '1526645557', '1526645557', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0767_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('20', '6', '1', '0', '天然素人 022416_01 野生妹在外打野砲！ 篠原仁美 ', '', 'tianransuren022416_01yeshengmeizaiwaidayepao_xiaoyuanrenmei', '1', 'T', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0758_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '927', '605', '541', '735', '', '777', '762', '7.0', '6475', '925', '1526645557', '1526645557', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0758_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('21', '6', '1', '0', 'HEYZO 0982 同栖生活 椎名有栖 ', '', 'HEYZO0982tongqishenghuozhuimingyouqi', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0777_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '749', '330', '229', '771', '', '313', '405', '1.0', '671', '671', '1526645558', '1526645558', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0777_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('22', '6', '1', '0', '加勒比 030216-108 美微乳 中村圣罗 ', '', 'jialebi030216_108meiweiruzhongcunshengluo', '1', 'J', '', '030216,加勒比', '无码中文av', 'http://img.feimanzb.com/2018-5/0768_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '438', '579', '971', '768', '', '592', '947', '8.0', '2776', '347', '1526645559', '1526645559', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0768_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('23', '6', '1', '0', '东京热 Tokyo Hot n1137 一刀两断究极凌辱 高田沙也加 ', '', 'dongjingreTokyoHotn1137yidaoliangduanjiujilingrugaotianshayejia', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0778_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '745', '101', '517', '476', '', '364', '137', '7.0', '4914', '702', '1526645559', '1526645559', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0778_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('24', '6', '1', '0', '东京热 Tokyo Hot n1136 肏到绝对服从 - 园田亚里沙 ', '', 'dongjingreTokyoHotn1136caodaojueduifucong_yuantianyalisha', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0779_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '418', '647', '619', '644', '', '377', '725', '4.0', '1948', '487', '1526645560', '1526645560', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0779_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('25', '6', '1', '0', '加勒比 081714-669 潮吹乱交天使 ～潮吹好女人们的大乱交～ 篠惠 川越结衣 小野麻里亚 ', '', 'jialebi081714_669chaochuiluanjiaotianshi_chaochuihaonvrenmendedaluanjiao_xiaohuichuanyuejieyixiaoyemaliya', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0789_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '209', '966', '25', '24', '', '383', '462', '6.0', '2706', '451', '1526645561', '1526645561', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0789_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('26', '6', '1', '0', '东京热 Tokyo Hot n1135 鬼畜集团轮姦受精地狱 绀野千里 ', '', 'dongjingreTokyoHotn1135guixujituanlunjianshoujingdiyuganyeqianli', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0780_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '867', '809', '485', '365', '', '131', '98', '2.0', '692', '346', '1526645562', '1526645562', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0780_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('27', '6', '1', '0', 'HEYZO 1092 让男优爆射就有奖 却被肉棒干到翻！- 川越结衣 ', '', 'HEYZO1092rangnanyoubaoshejiuyoujiangquebeiroubanggandaofan__chuanyuejieyi', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0790_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '142', '925', '751', '416', '', '371', '382', '9.0', '8280', '920', '1526645562', '1526645562', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0790_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('28', '6', '1', '0', '东京热 Tokyo Hot n1134 双姦 市川留美/羽田真里 ', '', 'dongjingreTokyoHotn1134shuangjianshichuanliumei_yutianzhenli', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0781_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '784', '64', '571', '929', '', '853', '64', '5.0', '4615', '923', '1526645563', '1526645563', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0781_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('29', '6', '1', '0', 'HEYZO 1116 累积巨乳微熟女快感爆表爽翻天！ - 高瀬杏 ', '', 'HEYZO1116leijijuruweishunvkuaiganbaobiaoshuangfantian__gaolaixing', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0791_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '544', '977', '696', '652', '', '327', '895', '6.0', '642', '107', '1526645564', '1526645564', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0791_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('30', '6', '1', '0', 'muramura 112115_314 21歳女子大生実録 橘理奈 ', '', 'muramura112115_31421suinvzidashengshilujulinai', '1', 'M', '', 'muramura,112115', '无码中文av', 'http://img.feimanzb.com/2018-5/0782_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '171', '413', '875', '336', '', '544', '624', '10.0', '2200', '220', '1526645564', '1526645564', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0782_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('31', '6', '1', '0', 'C0930 gol0136 羽田 まなみ Manami Haneda ', '', 'C0930gol0136yutian___ManamiHaneda', '1', 'C', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0792_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '415', '123', '859', '732', '', '252', '2', '5.0', '60', '12', '1526645567', '1526645567', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0792_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('32', '6', '1', '0', 'Muramura 031016_363 过去ＡＶ出演若妻~矢井田绫子 ', '', 'Muramura031016_363guoqu__chuyanruoqi_shijingtianlingzi', '1', 'M', '', 'Muramura,031016', '无码中文av', 'http://img.feimanzb.com/2018-5/0783_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '26', '856', '398', '588', '', '203', '778', '9.0', '2115', '235', '1526645568', '1526645568', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0783_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('33', '6', '1', '0', '一本道 021916_248 极射 叶山瞳 ', '', 'yibendao021916_248jisheyeshantong', '1', 'Y', '', '一本道,021916', '无码中文av', 'http://img.feimanzb.com/2018-5/0793_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '754', '362', '241', '655', '', '146', '703', '9.0', '5733', '637', '1526645568', '1526645568', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0793_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('34', '6', '1', '0', '加勒比PPV动画 041814_823 和亲爱的朝夕相处的中出生活?（挚爱潮吹）: 二宫奈奈 ', '', 'jialebiPPVdonghua041814_823heqinaidechaoxixiangchudezhongchushenghuo__zhiaichaochui__ergongnainai', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0784_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '349', '393', '140', '683', '', '832', '526', '2.0', '1938', '969', '1526645569', '1526645569', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0784_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('35', '6', '1', '0', '一本道 031516_262 共有少女 月野美羽 ', '', 'yibendao031516_262gongyoushaonvyueyemeiyu', '1', 'Y', '', '一本道,031516', '无码中文av', 'http://img.feimanzb.com/2018-5/0794_Sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '562', '696', '843', '422', '', '9', '997', '5.0', '4900', '980', '1526645570', '1526645570', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0794_Sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('36', '6', '1', '0', 'H0930 gol164 羽田 まなみ Manami Haneda ', '', 'H0930gol164yutian___ManamiHaneda', '1', 'H', '', 'Haneda,Manami,gol164', '无码中文av', 'http://img.feimanzb.com/2018-5/0785_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '142', '23', '100', '622', '', '429', '867', '7.0', '2947', '421', '1526645570', '1526645570', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0785_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('37', '6', '1', '0', '一本道 110315_182 名模精选 优雅 宫崎爱莉 ', '', 'yibendao110315_182mingmojingxuanyouyagongqiaili', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0795_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '839', '123', '662', '33', '', '841', '885', '5.0', '210', '42', '1526645571', '1526645571', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0795_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('38', '6', '1', '0', 'Av-sikou 0017 AV志向 0017 イラマチオ顽张ったよ 恵美 ', '', 'Av_sikou0017AVzhixiang0017_____wanzhang___huimei', '1', 'A', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0786_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '403', '747', '279', '405', '', '995', '802', '7.0', '4151', '593', '1526645572', '1526645572', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0786_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('39', '6', '1', '0', '东京热 Tokyo Hot n1101 淫叫超M母狗调教 今井圆 ', '', 'dongjingreTokyoHotn1101yinjiaochaoMmugoudiaojiaojinjingyuan', '1', 'D', '', '东京热,母狗,今井圆', '无码中文av', 'http://img.feimanzb.com/2018-5/0796_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '585', '644', '701', '487', '', '641', '367', '9.0', '7407', '823', '1526645572', '1526645572', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0796_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('40', '6', '1', '0', '加勒比 032516-125 扮装妹中出外拍 早乙女爱 ', '', 'jialebi032516_125banzhuangmeizhongchuwaipaizaoyinvai', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0787_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '133', '565', '677', '31', '', '529', '331', '9.0', '4347', '483', '1526645573', '1526645573', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0787_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('41', '6', '1', '0', '东京热 Tokyo Hot n1100 内射奴隷肏到精神崩壊契约 柴崎真希 ', '', 'dongjingreTokyoHotn1100neishenulicaodaojingshenbenghuaiqiyuechaiqizhenxi', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0797_Sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '799', '259', '958', '786', '', '410', '443', '6.0', '1932', '322', '1526645574', '1526645574', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0797_Sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('42', '6', '1', '0', '加勒比 032916-127 Debut 27 ～说AV无理结果还是来拍啦～ 成宫晴明 ', '', 'jialebi032916_127Debut27_shuoAVwulijieguohuanshilaipaila_chenggongqingming', '1', 'J', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0788_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '332', '477', '294', '501', '', '33', '453', '6.0', '552', '92', '1526645575', '1526645575', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0788_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('43', '6', '1', '0', '东京热 Tokyo Hot n1098 一刀两断究极凌辱 樱井菜菜 ', '', 'dongjingreTokyoHotn1098yidaoliangduanjiujilingruyingjingcaicai', '1', 'D', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0798_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '482', '967', '434', '928', '', '148', '112', '6.0', '3246', '541', '1526645575', '1526645575', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0798_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('44', '6', '1', '0', 'HEYZO 0877 沉溺淫乐女教师～新手上路蕩教课～ - 瞳由良 ', '', 'HEYZO0877chenniyinlenvjiaoshi_xinshoushangludangjiaoke__tongyouliang', '1', 'H', '', '0877,淫乐女教师,教课', '无码中文av', 'http://img.feimanzb.com/2018-5/0799_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '999', '482', '129', '815', '', '505', '170', '5.0', '2095', '419', '1526645576', '1526645576', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0799_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('45', '12', '1', '0', 'SHE-398 打手枪鉴赏会 让害羞素人妹看我尻枪 26 ', '', 'SHE_398dashouqiangjianshanghuiranghaixiusurenmeikanwokaoqiang26', '1', 'S', '', 'SHE', '出轨中文av', 'http://img.feimanzb.com/2018-5/EAET4JKO398.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '634', '770', '129', '914', '', '854', '376', '10.0', '4780', '478', '1526645577', '1526645577', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EAET4JKO398/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('46', '11', '1', '0', 'IENE-742 男女好朋友 敢隔着保鲜膜和体验素股吗？不小心插入了！！ ', '', 'IENE_742nannvhaopengyougangezhuobaoxianmohetiyansuguma_buxiaoxincharuliao__', '1', 'I', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EHJ5OTR742.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '136', '581', '184', '973', '', '946', '480', '8.0', '3728', '466', '1526645577', '1526645577', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHJ5OTR742/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('47', '6', '1', '0', 'HEYZO 0906 肏到人妻满足吧～老公都不干我～ - 逢泽遥 ', '', 'HEYZO0906caodaorenqimanzuba_laogongdubuganwo__fengzeyao', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0800_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '254', '666', '43', '743', '', '530', '232', '7.0', '931', '133', '1526645581', '1526645581', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0800_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('48', '8', '1', '0', 'LOVE-336 爆奶！爆漂亮！请告诉这个正妹的名字！被抽插到痉挛绝顶尖叫的G罩杯正妹！ ', '', 'LOVE_336baonai_baopiaoliang_qinggaosuzhegezhengmeidemingzi_beichouchadaojingluanjuedingjianjiaodeGzhaobeizhengmei_', '1', 'L', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EAT8HJO336.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '741', '774', '457', '974', '', '356', '384', '5.0', '1155', '231', '1526645582', '1526645582', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EAT8HJO336/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('49', '9', '1', '0', 'IENE-683 巨乳妈见儿子晨勃大兴奋 2 ', '', 'IENE_683jurumajianerzichenbodaxingfen2', '1', 'I', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EHJ5RYN683.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '344', '655', '175', '417', '', '174', '683', '8.0', '4064', '508', '1526645583', '1526645583', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHJ5RYN683/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('50', '6', '1', '0', 'HEYZO 1002 淫女被降职到性处理部门 - 三浦春佳 ', '', 'HEYZO1002yinnvbeijiangzhidaoxingchulibumen_sanpuchunjia', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0801_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '814', '60', '948', '820', '', '734', '881', '5.0', '3575', '715', '1526645583', '1526645583', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0801_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('51', '10', '1', '0', 'LOVE-340 我想成为AV女优。在新宿发现的现任服饰店店员 水奈麻衣 18岁出道 ', '', 'LOVE_340woxiangchengweiAVnvyou_zaixinsufaxiandexianrenfushidiandianyuanshuinaimayi18suichudao', '1', 'L', '', 'LOVE', '制服中文av', 'http://img.feimanzb.com/2018-5/EBT2NJO340.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '902', '739', '526', '934', '', '787', '728', '2.0', '1202', '601', '1526645584', '1526645584', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EBT2NJO340/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('52', '12', '1', '0', 'SDDE-456 开朗！柔软胸部！有破绽！用下半身治癒客人的浴场看板娘 ', '', 'SDDE_456kailang_rouruanxiongbu_youpozhan_yongxiabanshenzhiyukerendeyuchangkanbanniang', '1', 'S', '', '', '出轨中文av', 'http://img.feimanzb.com/2018-5/EHJ7OTN456.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '357', '441', '659', '509', '', '81', '972', '8.0', '7336', '917', '1526645585', '1526645585', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHJ7OTN456/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('53', '11', '1', '0', 'MIDE-360 写真天王来干4砲！ 高桥圣子 ', '', 'MIDE_360xiezhentianwanglaigan4pao_gaoqiaoshengzi', '1', 'M', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EHJO5WGR360.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '929', '916', '96', '295', '', '368', '366', '10.0', '4130', '413', '1526645585', '1526645585', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHJO5WGR360/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('54', '8', '1', '0', 'MIAE-027 喷汗竞赛泳装妹和大叔干翻天 立花瑠莉 ', '', 'MIAE_027penhanjingsaiyongzhuangmeihedashuganfantianlihualiuli', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EBT4HJO027.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '368', '915', '588', '41', '', '397', '658', '5.0', '4195', '839', '1526645586', '1526645586', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EBT4HJO027/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('55', '6', '1', '0', '天然素人 111315_01 用高难度抽插技巧和按摩棒满足她! 大冢由美 ', '', 'tianransuren111315_01yonggaonanduchouchajiqiaoheanmobangmanzuta_dazhongyoumei', '1', 'T', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0802_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '424', '187', '885', '499', '', '918', '598', '1.0', '944', '944', '1526645587', '1526645587', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0802_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('56', '11', '1', '0', 'MIDE-340 妻子被睡走实况影片 特别篇 秋山祥子 ', '', 'MIDE_340qizibeishuizoushikuangyingpiantebiepianqiushanxiangzi', '1', 'M', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/EHL6OPN340.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '848', '483', '736', '418', '', '682', '936', '5.0', '2395', '479', '1526645587', '1526645587', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHL6OPN340/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('57', '11', '1', '0', 'MIDE-405 爽到你发疯 肏到痉挛狂喷潮 秋山祥子 ', '', 'MIDE_405shuangdaonifafengcaodaojingluankuangpenchaoqiushanxiangzi', '1', 'M', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EBT6HJO405.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '389', '552', '892', '547', '', '437', '423', '5.0', '965', '193', '1526645588', '1526645588', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EBT6HJO405/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('58', '6', '1', '0', '天然素人 092115_01 逆立口交初体验~绫瀬まゆ ', '', 'tianransuren092115_01nilikoujiaochutiyan_linglai__', '1', 'T', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0803_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '797', '144', '103', '638', '', '935', '809', '9.0', '7542', '838', '1526645589', '1526645589', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0803_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('59', '12', '1', '0', 'SQTE-157 平静相互索求的爱情SEX ', '', 'SQTE_157pingjingxianghusuoqiudeaiqingSEX', '1', 'S', '', 'SQTE', '出轨中文av', 'http://img.feimanzb.com/2018-5/EHQ9RKP157.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '822', '10', '118', '440', '', '925', '843', '3.0', '486', '162', '1526645590', '1526645590', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHQ9RKP157/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('60', '6', '1', '0', '天然素人 091515_01 制服时代 内田凉子 ', '', 'tianransuren091515_01zhifushidaineitianliangzi', '1', 'T', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0804_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '214', '900', '688', '702', '', '157', '275', '6.0', '5490', '915', '1526645590', '1526645590', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0804_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('61', '8', '1', '0', 'SDDE-470 世界最迷你109公分导演小西来拍A片啦！ 波多野结衣 ', '', 'SDDE_470shijiezuimini109gongfendaoyanxiaoxilaipaiApianla_boduoyejieyi', '1', 'S', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EGR7WJO470.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '724', '563', '563', '175', '', '382', '856', '5.0', '4245', '849', '1526645593', '1526645593', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EGR7WJO470/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('62', '10', '1', '0', 'MIAD-987 对满身汗水的学生发情让完全勃起的肉棒射精的闷热丝袜女教师 本田岬 ', '', 'MIAD_987duimanshenhanshuidexueshengfaqingrangwanquanboqideroubangshejingdemenresiwanvjiaoshibentianjia', '1', 'M', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DWJ8TYU987.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '100', '749', '492', '610', '', '348', '335', '7.0', '4984', '712', '1526645593', '1526645593', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DWJ8TYU987/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('63', '11', '1', '0', 'IENE-685 经验丰富又温柔的素人人妻的最棒童贞破处 ', '', 'IENE_685jingyanfengfuyouwenroudesurenrenqidezuibangtongzhenpochu', '1', 'I', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/EHA9TJO685.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '94', '209', '226', '755', '', '807', '463', '9.0', '2286', '254', '1526645595', '1526645595', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHA9TJO685/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('64', '8', '1', '0', 'MIDE-345 超威乳摇骑乘位 JULIA ', '', 'MIDE_345chaoweiruyaoqichengweiJULIA', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EHR2YBC345.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '455', '692', '515', '361', '', '508', '989', '1.0', '227', '227', '1526645595', '1526645595', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHR2YBC345/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('65', '7', '1', '0', 'SHKD-725 强暴的房间 希美真由 ', '', 'SHKD_725qiangbaodefangjianximeizhenyou', '1', 'S', '', '', '强奸中文av', 'http://img.feimanzb.com/2018-5/DWT8HJO725.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '934', '948', '109', '178', '', '201', '664', '8.0', '3032', '379', '1526645596', '1526645596', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DWT8HJO725/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('66', '8', '1', '0', 'IENE-749 对于自己平胸感到自卑的女高中生，光是因为「看到她的胸罩及乳头」就马上勃起就深情凝视着我说「这样的奶也可以吗？」渴求我的插入！ ', '', 'IENE_749duiyuzijipingxionggandaozibeidenvgaozhongsheng_guangshiyinwei_kandaotadexiongzhaojirutou_jiumashangboqijiushenqingningshizhuowoshuo_zheyangdenaiyekeyima__keqiuwodecharu_', '1', 'I', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EHET2JOM749.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '279', '728', '757', '956', '', '636', '237', '8.0', '3688', '461', '1526645597', '1526645597', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHET2JOM749/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('67', '8', '1', '0', 'MIAE-024 让你看见内裤跟胸部、强制让你勃起后宫干翻天！ ', '', 'MIAE_024rangnikanjianneikugenxiongbu_qiangzhirangniboqihougongganfantian_', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EHR6WJO024.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '242', '782', '210', '445', '', '564', '458', '9.0', '1998', '222', '1526645598', '1526645598', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHR6WJO024/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('68', '8', '1', '0', 'UMD-557 从内裤溢出好多爱液！！马上就想被插入的巨乳人妻们淫水直流的涂油按摩 ', '', 'UMD_557congneikuyichuhaoduoaiye__mashangjiuxiangbeicharudejururenqimenyinshuizhiliudetuyouanmo', '1', 'U', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DYI3LNY557.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '572', '859', '217', '395', '', '734', '78', '9.0', '3717', '413', '1526645598', '1526645598', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DYI3LNY557/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('69', '9', '1', '0', 'MIDE-380 大姊骑乘位压榨肉棒！ 神咲诗织 ', '', 'MIDE_380daziqichengweiyazharoubang_shenxiaoshizhi', '1', 'M', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EHI3TEN380.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '19', '709', '530', '556', '', '895', '846', '4.0', '3136', '784', '1526645599', '1526645599', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHI3TEN380/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('70', '8', '1', '0', 'MIDE-383 女体控制者的下半身强制操作 蕾 ', '', 'MIDE_383nvtikongzhizhedexiabanshenqiangzhicaozuolei', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EHT0JKP383.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '333', '83', '896', '678', '', '799', '513', '3.0', '255', '85', '1526645600', '1526645600', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHT0JKP383/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('71', '10', '1', '0', 'RBD-772 废材员工肏翻人人想干的女上司 松下纱荣子 ', '', 'RBD_772feicaiyuangongcaofanrenrenxianggandenvshangsisongxiasharongzi', '1', 'R', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DZM6KRU772.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '264', '730', '68', '511', '', '196', '828', '3.0', '195', '65', '1526645603', '1526645603', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DZM6KRU772/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('72', '12', '1', '0', 'MIDE-352 第一次高潮！ 千早希 ', '', 'MIDE_352diyicigaochao_qianzaoxi', '1', 'M', '', '', '出轨中文av', 'http://img.feimanzb.com/2018-5/EHJ5OPN352.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '563', '401', '794', '805', '', '834', '542', '1.0', '475', '475', '1526645604', '1526645604', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHJ5OPN352/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('73', '11', '1', '0', 'MIDE-327 干到全身狂喷汁大洪水 神咲诗织 ', '', 'MIDE_327gandaoquanshenkuangpenzhidahongshuishenxiaoshizhi', '1', 'M', '', 'MIDE', '调教中文av', 'http://img.feimanzb.com/2018-5/EHT5JOA327.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '979', '845', '825', '309', '', '465', '404', '5.0', '325', '65', '1526645605', '1526645605', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHT5JOA327/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('74', '11', '1', '0', 'SDDE-459 「常在干砲」 温泉旅馆 ', '', 'SDDE_459_changzaiganpao_wenquanlvguan', '1', 'S', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EHW0TRJO459.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '262', '812', '911', '775', '', '838', '164', '2.0', '1168', '584', '1526645606', '1526645606', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHW0TRJO459/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('75', '8', '1', '0', 'SDDE-452 「时常作爱」 比基尼按摩4 由F罩杯以上巨乳美容师带来的极品油压按摩 完整欧洲风按摩篇 ', '', 'SDDE_452_shichangzuoai_bijinianmo4youFzhaobeiyishangjurumeirongshidailaidejipinyouyaanmowanzhengouzhoufenganmopian', '1', 'S', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJK8ONH452.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '162', '53', '801', '951', '', '703', '573', '10.0', '7830', '783', '1526645606', '1526645606', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJK8ONH452/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('76', '8', '1', '0', 'IENE-660 狂玩奶头男用按摩店 ', '', 'IENE_660kuangwannaitounanyonganmodian', '1', 'I', '', 'IENE', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EHW2VKD660.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '429', '318', '247', '589', '', '810', '381', '7.0', '2877', '411', '1526645607', '1526645607', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EHW2VKD660/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('77', '9', '1', '0', 'MIDE-372 堂姐来玩翻兄弟肉棒看爆射… 蕾 ', '', 'MIDE_372tangjielaiwanfanxiongdiroubangkanbaoshe_lei', '1', 'M', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EJK56RHY372.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '814', '356', '996', '437', '', '909', '336', '9.0', '1980', '220', '1526645608', '1526645608', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJK56RHY372/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('78', '9', '1', '0', 'SHE-278 在断言说对母亲不会勃起的儿子面前让母亲高潮秀！勃起的话惩罚游戏近亲相姦无套内设！ ', '', 'SHE_278zaiduanyanshuoduimuqinbuhuiboqideerzimianqianrangmuqingaochaoxiu_boqidehuachengfayouxijinqinxiangjianwutaoneishe_', '1', 'S', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EIZ0JYH278.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '65', '917', '801', '246', '', '751', '191', '5.0', '4790', '958', '1526645608', '1526645608', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EIZ0JYH278/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('79', '9', '1', '0', 'MIDE-373 突袭你家干砲传说 JULIA ', '', 'MIDE_373tuxinijiaganpaochuanshuoJULIA', '1', 'M', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EJKP5RYN373.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '934', '752', '410', '767', '', '84', '693', '1.0', '376', '376', '1526645609', '1526645609', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJKP5RYN373/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('80', '11', '1', '0', 'MIDE-321 爽到你发疯 肏到痉挛狂喷潮 初音实 ', '', 'MIDE_321shuangdaonifafengcaodaojingluankuangpenchaochuyinshi', '1', 'M', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EJA7YON321.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '170', '610', '574', '748', '', '660', '595', '6.0', '1338', '223', '1526645610', '1526645610', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJA7YON321/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('81', '8', '1', '0', 'IENE-654 巨乳心疗师来你家啦 ', '', 'IENE_654juruxinliaoshilainijiala', '1', 'I', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJN8HMC654.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '523', '241', '42', '940', '', '228', '644', '7.0', '1750', '250', '1526645611', '1526645611', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJN8HMC654/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('82', '8', '1', '0', 'MIDE-368 大口吸肉棒口交癡女 神咲诗织 ', '', 'MIDE_368dakouxiroubangkoujiaochinvshenxiaoshizhi', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJG7HYN368.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '744', '396', '565', '93', '', '539', '592', '1.0', '207', '207', '1526645611', '1526645611', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJG7HYN368/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('83', '11', '1', '0', 'MIDE-404 人渣前男友偷拍的掠夺视频 JULIA ', '', 'MIDE_404renzhaqiannanyoutoupaidelueduoshipinJULIA', '1', 'M', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EJO0GTR404.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '582', '825', '893', '957', '', '341', '189', '6.0', '5058', '843', '1526645612', '1526645612', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO0GTR404/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('84', '9', '1', '0', 'MIDE-378 爱正太的大姐姐淫奶诱惑姦！ 初川南 ', '', 'MIDE_378aizhengtaidedajiejieyinnaiyouhuojian_chuchuannan', '1', 'M', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/EJG9TNO378.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '786', '277', '776', '282', '', '386', '183', '10.0', '9100', '910', '1526645613', '1526645613', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJG9TNO378/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('85', '8', '1', '0', 'SDDE-445 目测F罩杯以上 在青山找到的巨乳人妻 用时间停止来拍A片！～真正中出篇～ ', '', 'SDDE_445muceFzhaobeiyishangzaiqingshanzhaodaodejururenqiyongshijiantingzhilaipaiApian__zhenzhengzhongchupian_', '1', 'S', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJO0RNY445.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '108', '502', '963', '818', '', '423', '327', '9.0', '1395', '155', '1526645613', '1526645613', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO0RNY445/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('86', '11', '1', '0', 'IENE-719 老练素人妻顶级帮你脱童贞 7 ', '', 'IENE_719laoliansurenqidingjibangnituotongzhen7', '1', 'I', '', 'IENE', '人妻中文av', 'http://img.feimanzb.com/2018-5/EJH0TRO719.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '298', '251', '205', '315', '', '202', '368', '1.0', '331', '331', '1526645614', '1526645614', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJH0TRO719/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('87', '12', '1', '0', 'SDDE-448 「常在干砲」 女僕按摩店 ', '', 'SDDE_448_changzaiganpao_nvpuanmodian', '1', 'S', '', '', '出轨中文av', 'http://img.feimanzb.com/2018-5/EJO0RUB448.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '104', '273', '252', '523', '', '473', '59', '5.0', '930', '186', '1526645615', '1526645615', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO0RUB448/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('88', '8', '1', '0', 'HONE-205 近亲相姦 爆乳浴室 岛津薫 ', '', 'HONE_205jinqinxiangjianbaoruyushidaojinxun', '1', 'H', '', 'HONE', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJK0ORY205.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '278', '319', '853', '191', '', '986', '147', '7.0', '3297', '471', '1526645615', '1526645615', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJK0ORY205/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('89', '10', '1', '0', 'HNSE-002 宽鬆世代AV出道 现役女大学生 香奈 19岁 G罩杯！！ ', '', 'HNSE_002kuansongshidaiAVchudaoxianyinvdaxueshengxiangnai19suiGzhaobei__', '1', 'H', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/EJO2ATH002.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '568', '138', '759', '71', '', '492', '384', '4.0', '3744', '936', '1526645619', '1526645619', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO2ATH002/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('90', '10', '1', '0', 'SDDE-430 打枪干砲诊所 2016年感谢祭！ ', '', 'SDDE_430daqiangganpaozhensuo2016nianganxieji_', '1', 'S', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/EJK2IYQ430.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '726', '480', '720', '912', '', '740', '520', '5.0', '1650', '330', '1526645620', '1526645620', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJK2IYQ430/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('91', '12', '1', '0', 'HD MIDE-322 两天一夜中出温泉之旅 伊东千奈美高清 ', '', 'HDMIDE_322liangtianyiyezhongchuwenquanzhilvyidongqiannaimeigaoqing', '1', 'H', '', 'MIDE', '出轨中文av', 'http://img.feimanzb.com/2018-5/EJO2ETH322.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '502', '96', '485', '463', '', '480', '304', '7.0', '2828', '404', '1526645622', '1526645622', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO2ETH322/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('92', '11', '1', '0', 'SQTE-153 满意爱情的美少女服侍口交35连发 S-Cute口交精选集 2017 ', '', 'SQTE_153manyiaiqingdemeishaonvfushikoujiao35lianfaS_Cutekoujiaojingxuanji2017', '1', 'S', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/EJK7ZPY153.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '644', '736', '805', '475', '', '462', '486', '8.0', '7264', '908', '1526645623', '1526645623', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJK7ZPY153/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('93', '11', '1', '0', 'SHE-373 和人妻外遇温泉旅行 远离都心贪婪背德快感的9名人妻们 ', '', 'SHE_373herenqiwaiyuwenquanlvxingyuanliduxintanlanbeidekuaigande9mingrenqimen', '1', 'S', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/EJO2ETH373.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '903', '149', '430', '699', '', '436', '817', '4.0', '2364', '591', '1526645624', '1526645624', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO2ETH373/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('94', '8', '1', '0', 'GNE-155 出租巨乳妹给你干 01 ', '', 'GNE_155chuzujurumeigeinigan01', '1', 'G', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJO3RHY155.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '30', '85', '109', '883', '', '153', '46', '3.0', '612', '204', '1526645624', '1526645624', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO3RHY155/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('95', '10', '1', '0', 'WPE-43 人妻情趣内衣 原千岁 ', '', 'WPE_43renqiqingquneiyiyuanqiansui', '1', 'W', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/EJO3RYN43.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '774', '295', '593', '778', '', '362', '924', '3.0', '1491', '497', '1526645625', '1526645625', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO3RYN43/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('96', '8', '1', '0', 'SQTE-149 胸部漂亮的人，好色的人很多是真的吗？ ', '', 'SQTE_149xiongbupiaoliangderen_haosederenhenduoshizhendema_', '1', 'S', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJO3THY149.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '885', '528', '632', '135', '', '813', '200', '2.0', '438', '219', '1526645626', '1526645626', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO3THY149/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('97', '8', '1', '0', 'IENE-713 3天一起吃睡干砲高级美女泡泡浴 西川结衣 ', '', 'IENE_7133tianyiqichishuiganpaogaojimeinvpaopaoyuxichuanjieyi', '1', 'I', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/EJO4PNY713.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '113', '534', '976', '702', '', '256', '625', '7.0', '847', '121', '1526645627', '1526645627', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO4PNY713/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('98', '10', '1', '0', 'HNSE-003 第一次与大叔作爱...大学时因故没拍片的现任女大生破处拍AV 文学院3年级 美步纱也加 ', '', 'HNSE_003diyiciyudashuzuoai___daxueshiyingumeipaipiandexianrennvdashengpochupaiAVwenxueyuan3nianjimeibushayejia', '1', 'H', '', 'HNSE', '制服中文av', 'http://img.feimanzb.com/2018-5/EJO4RNY003.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '209', '64', '374', '230', '', '441', '948', '5.0', '4765', '953', '1526645627', '1526645627', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO4RNY003/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('99', '12', '1', '0', 'MIDE-379 究极女僕浓情干砲性服务 高桥圣子 ', '', 'MIDE_379jiujinvpunongqingganpaoxingfuwugaoqiaoshengzi', '1', 'M', '', '', '出轨中文av', 'http://img.feimanzb.com/2018-5/EJO4YHN379.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '921', '868', '577', '469', '', '119', '919', '3.0', '1392', '464', '1526645628', '1526645628', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/EJO4YHN379/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('100', '10', '1', '0', 'PGD-897 PREMIUM STYLISH SOAP GOLD 流行泡泡浴场 铃木真夕  ', '', 'PGD_897PREMIUMSTYLISHSOAPGOLDliuxingpaopaoyuchanglingmuzhenxi', '1', 'P', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DQH9NOB897.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '303', '601', '376', '55', '', '852', '775', '1.0', '479', '479', '1526651873', '1526651873', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH9NOB897/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('101', '6', '1', '0', '一本道 021816_247 超爱干砲妹等你来肏 春日野结衣 ', '', 'yibendao021816_247chaoaiganpaomeidengnilaicaochunriyejieyi', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0751_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '595', '26', '885', '112', '', '125', '72', '7.0', '6559', '937', '1526651873', '1526651873', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0751_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('102', '10', '1', '0', 'EBOD-518 学生妹爱和援交大叔秒插到射好射满！ 铃木真夕 ', '', 'EBOD_518xueshengmeiaiheyuanjiaodashumiaochadaoshehaosheman_lingmuzhenxi', '1', 'E', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DPK5RUY518.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '535', '131', '479', '535', '', '420', '923', '4.0', '3420', '855', '1526651874', '1526651874', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DPK5RUY518/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('103', '11', '1', '0', 'MIAD-970 抓双马尾骑车口爆 迹美朱里 ', '', 'MIAD_970zhuashuangmaweiqichekoubaojimeizhuli', '1', 'M', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/DQJ0OGN970.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '874', '666', '909', '76', '', '489', '79', '2.0', '1970', '985', '1526651875', '1526651875', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQJ0OGN970/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('104', '6', '1', '0', '一本道 030316_255 让不知世故妹下海来拍片！ 前原沙良 ', '', 'yibendao030316_255rangbuzhishigumeixiahailaipaipian_qianyuanshaliang', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0752_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '361', '381', '926', '484', '', '82', '290', '7.0', '532', '76', '1526651878', '1526651878', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0752_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('105', '8', '1', '0', 'CESD-227 和中年大叔黏密干砲 2 吹石玲奈 ', '', 'CESD_227hezhongniandashunianmiganpao2chuishilingnai', '1', 'C', '', 'CESD', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DQ6HYRJ227.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '746', '25', '278', '509', '', '948', '305', '7.0', '6139', '877', '1526651879', '1526651879', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQ6HYRJ227/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('106', '11', '1', '0', 'JUFD-674 慾求不满人妻淫鲍狂诱惑 榨光浓精吸进穴内 谷原希美 ', '', 'JUFD_674yuqiubumanrenqiyinbaokuangyouhuozhaguangnongjingxijinxueneiguyuanximei', '1', 'J', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/DQJ2PGR674.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '780', '349', '716', '902', '', '837', '875', '9.0', '1260', '140', '1526651880', '1526651880', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQJ2PGR674/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('107', '6', '1', '0', '一本道 031216_261 火辣巨乳女 北山柑菜 ', '', 'yibendao031216_261huolajurunvbeishangancai', '1', 'Y', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0753_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '213', '103', '990', '411', '', '500', '750', '1.0', '613', '613', '1526651881', '1526651881', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0753_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('108', '12', '1', '0', 'HBAD-325 我是最爱大叔的受虐狂?黒木郁美 23歳、年轻男人没感觉 想被大叔侵犯出道 ', '', 'HBAD_325woshizuiaidashudeshounuekuang_heimuyumei23sui_nianqingnanrenmeiganjuexiangbeidashuqinfanchudao', '1', 'H', '', '', '出轨中文av', 'http://img.feimanzb.com/2018-5/DQH2JNB325.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '794', '36', '851', '788', '', '686', '680', '1.0', '47', '47', '1526651881', '1526651881', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH2JNB325/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('109', '9', '1', '0', 'MIRD-169 和10位超欠干妹妹一起住的哥哥 ', '', 'MIRD_169he10weichaoqianganmeimeiyiqizhudegege', '1', 'M', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/DQJ6OHB169.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '273', '899', '47', '782', '', '146', '414', '5.0', '965', '193', '1526651882', '1526651882', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQJ6OHB169/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('110', '8', '1', '0', 'SPRD-910 那时候的欧巴桑 村上凉子 ', '', 'SPRD_910nashihoudeoubasangcunshangliangzi', '1', 'S', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DQH2OJY910.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '400', '442', '329', '143', '', '629', '703', '2.0', '1598', '799', '1526651883', '1526651883', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH2OJY910/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('111', '6', '1', '0', 'HEYZO 1115 私底下肏翻AV女优！- 铃羽美羽 ', '', 'HEYZO1115sidixiacaofanAVnvyou__lingyumeiyu', '1', 'H', '', '', '无码中文av', 'http://img.feimanzb.com/2018-5/0754_sd.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '927', '414', '447', '621', '', '886', '296', '9.0', '5544', '616', '1526651884', '1526651884', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180510/0754_sd/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('112', '8', '1', '0', 'KAWD-726 kawaii*专属出道 真正纯朴女 AV史上最紧张的镜头前初性交 小池里菜 ', '', 'KAWD_726kawaii_zhuanshuchudaozhenzhengchunpunvAVshishangzuijinzhangdejingtouqianchuxingjiaoxiaochilicai', '1', 'K', '', 'KAWD', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DQJ9MPG726.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '601', '567', '150', '967', '', '666', '944', '4.0', '1576', '394', '1526651884', '1526651884', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQJ9MPG726/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('113', '10', '1', '0', 'KAWD-724 现役女大生也让人射进去啦 绪奈萌 ', '', 'KAWD_724xianyinvdashengyerangrenshejinqulaxunaimeng', '1', 'K', '', 'KAWD', '制服中文av', 'http://img.feimanzb.com/2018-5/DQH3ERY724.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '174', '648', '190', '929', '', '719', '397', '3.0', '2649', '883', '1526651885', '1526651885', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH3ERY724/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('114', '8', '1', '0', 'MIBD-993 发情辣妹被肏到爽翻天 ', '', 'MIBD_993faqinglameibeicaodaoshuangfantian', '1', 'M', '', 'MIBD', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DOJ9ZRY993.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '396', '410', '316', '259', '', '796', '405', '5.0', '4165', '833', '1526651886', '1526651886', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DOJ9ZRY993/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('115', '8', '1', '0', 'MIAD-920 高潮微乳窈窕妹 土屋朝美 ', '', 'MIAD_920gaochaoweiruyaotiaomeituwuchaomei', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DQJ9OHY920.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '15', '601', '278', '706', '', '647', '717', '6.0', '5964', '994', '1526651886', '1526651886', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQJ9OHY920/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('116', '11', '1', '0', 'HZGD-010 超正传播少妻奴隶游戏 羽月希 ', '', 'HZGD_010chaozhengchuanboshaoqinuliyouxiyuyuexi', '1', 'H', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/DQH4ETY010.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '784', '972', '825', '20', '', '20', '84', '5.0', '580', '116', '1526651887', '1526651887', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH4ETY010/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('117', '11', '1', '0', 'HZGD-006 想被干的继承家产少妻 KAORI ', '', 'HZGD_006xiangbeigandejichengjiachanshaoqiKAORI', '1', 'H', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/DOL6RHY006.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '451', '272', '709', '952', '', '668', '256', '9.0', '8532', '948', '1526651888', '1526651888', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DOL6RHY006/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('118', '8', '1', '0', 'CESD-312 爽到喷了一地都是淫水真抱歉… 本田岬 ', '', 'CESD_312shuangdaopenliaoyididushiyinshuizhenbaoqian_bentianjia', '1', 'C', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DQP8THE312.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '766', '253', '678', '250', '', '338', '982', '6.0', '1452', '242', '1526651889', '1526651889', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQP8THE312/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('119', '11', '1', '0', 'MEYD-172 再现从素人投稿来的实际故事 真的发生过的人妻们淫乱体验故事 东凛 ', '', 'MEYD_172zaixiancongsurentougaolaideshijigushizhendefashengguoderenqimenyinluantiyangushidonglin', '1', 'M', '', '', '人妻中文av', 'http://img.feimanzb.com/2018-5/DQH5NOH172.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '479', '662', '484', '666', '', '782', '13', '2.0', '1494', '747', '1526651889', '1526651889', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH5NOH172/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('120', '10', '1', '0', 'CJOD-037 最爱援交的蛇吻学生妹 迹美朱里 ', '', 'CJOD_037zuiaiyuanjiaodeshewenxueshengmeijimeizhuli', '1', 'C', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DOP2UIK037.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '341', '252', '875', '949', '', '750', '99', '6.0', '1272', '212', '1526651890', '1526651890', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DOP2UIK037/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('121', '11', '1', '0', 'JUFD-623 黑屌猛干肉弹战 织田真子 ', '', 'JUFD_623heidiaomengganroudanzhanzhitianzhenzi', '1', 'J', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/DQW7JOH623.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '102', '771', '602', '849', '', '991', '989', '4.0', '1556', '389', '1526651891', '1526651891', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQW7JOH623/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('122', '9', '1', '0', 'HZGD-008 在老公前被变态公公睡走… 篠田步美 ', '', 'HZGD_008zailaogongqianbeibiantaigonggongshuizou_xiaotianbumei', '1', 'H', '', 'HZGD', '乱伦中文av', 'http://img.feimanzb.com/2018-5/DQH5OGN008.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '511', '970', '416', '116', '', '255', '434', '5.0', '130', '26', '1526651891', '1526651891', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQH5OGN008/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('123', '10', '1', '0', 'MKMP-139 卧底搜查官 AIKA ', '', 'MKMP_139wodisouchaguanAIKA', '1', 'M', '', '', '制服中文av', 'http://img.feimanzb.com/2018-5/DPH0TJO139.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '318', '599', '65', '501', '', '293', '184', '6.0', '5250', '875', '1526651892', '1526651892', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DPH0TJO139/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('124', '11', '1', '0', 'SHKD-723 逃狱者 天海翼 ', '', 'SHKD_723taoyuzhetianhaiyi', '1', 'S', '', 'SHKD', '调教中文av', 'http://img.feimanzb.com/2018-5/DQW7NHJ723.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '274', '407', '300', '753', '', '854', '988', '5.0', '3420', '684', '1526651893', '1526651893', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DQW7NHJ723/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('125', '11', '1', '0', 'JUFD-684 只持续凝视着你的淫语内射泡泡浴 立花瑠莉 ', '', 'JUFD_684zhichixuningshizhuonideyinyuneishepaopaoyulihualiuli', '1', 'J', '', '', '调教中文av', 'http://img.feimanzb.com/2018-5/DRH8JOB684.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '128', '145', '871', '622', '', '689', '597', '8.0', '1632', '204', '1526651897', '1526651897', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DRH8JOB684/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('126', '9', '1', '0', 'HD CND-177 良家大小姐出演AV首秀 娇躯十分敏感，稍微亲一下小穴就湿润了 堀江真希高清 ', '', 'HDCND_177liangjiadaxiaojiechuyanAVshouxiujiaoqushifenmingan_shaoweiqinyixiaxiaoxuejiushirunliaokujiangzhenxigaoqing', '1', 'H', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/DST5HYK177.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '631', '563', '528', '858', '', '547', '761', '4.0', '740', '185', '1526651897', '1526651897', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DST5HYK177/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('127', '8', '1', '0', 'MILD-945 MILLION DREAM 2014 絶对战体MILLIGIRL Z 与宇宙生命体章鱼门‘高潮’大决战特别版 ', '', 'MILD_945MILLIONDREAM2014jueduizhantiMILLIGIRLZyuyuzhoushengmingtizhangyumen_gaochao_dajuezhantebieban', '1', 'M', '', '', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DRJ3YON945.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '532', '411', '21', '211', '', '179', '230', '10.0', '3780', '378', '1526651898', '1526651898', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DRJ3YON945/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('128', '9', '1', '0', 'PPPD-481 女友的巨乳姐姐内射OK诱惑 水野朝阳 ', '', 'PPPD_481nvyoudejurujiejieneisheOKyouhuoshuiyechaoyang', '1', 'P', '', '', '乱伦中文av', 'http://img.feimanzb.com/2018-5/DSW8QIK481.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '582', '438', '100', '431', '', '334', '753', '3.0', '1593', '531', '1526651899', '1526651899', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DSW8QIK481/650kb/hls/index.m3u8', '', '', '', '');
INSERT INTO `mac_vod` VALUES ('129', '8', '1', '0', 'JUFD-675 以仔细又高明的打手枪技巧陪伴你 让你完全勃起又射超多的回春旅馆 通野未帆 ', '', 'JUFD_675yizixiyougaomingdedashouqiangjiqiaopeibannirangniwanquanboqiyoushechaoduodehuichunlvguantongyeweifan', '1', 'J', '', 'JUFD', '巨乳中文av', 'http://img.feimanzb.com/2018-5/DRJ3YUK675.jpg', '', '', '', '', '', '', '中字', '', '0', '0', '', '', '日本', '日语', '2017', '', '', '', '', '', '', '', '1', '0', '0', '0', '0', '530', '394', '514', '269', '', '762', '81', '1.0', '395', '395', '1526651909', '1526651909', '0', '0', '0', '0', '0.0', '', '', '', '', 'ckplayer', 'no', '', 'http://video.lllwo2o.com:8091/20180501/DRJ3YUK675/650kb/hls/index.m3u8', '', '', '', '');
